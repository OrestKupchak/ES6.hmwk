let args = process.argv

console.log('Hello ' + `${args[2]}`)





