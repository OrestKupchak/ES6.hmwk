const max = +process.argv[2];
let FizzBuzz = {
  [Symbol.iterator]() {
    let curr = 1;
     let value ;
        return {
          next() {
            if (curr > max) {
              return { done: true };
            }
            value = curr;
            if (value % 5 === 0 && value % 3 === 0) {
              value = 'FizzBuzz';
            } else if (value % 3 === 0) {
              value = 'Fizz';
            } else if (value % 5 === 0) {
              value = 'Buzz';
            }
            curr++;
            return { done: false, value: value };
          }
        }
      }
    }

for (var n of FizzBuzz) {
  console.log(n);
}
