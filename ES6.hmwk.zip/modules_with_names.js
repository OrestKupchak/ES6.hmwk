 // (Math.js)

 export const PI = 3.141592;

const _sqrt = (s, x, last) => {
      return x != last ? _sqrt(s, (x + s / x) / 2.0, x) : x;
    };

export const sqrt = (s) => {
      return _sqrt(s, s/2.0, 0.0);
    };

export const square = (x) => {
      return x * x;
    };





// (Main.js)
import {PI, sqrt, square} from './Math'

  let arg1 = process.argv[2];
  let arg2 = process.argv[3];

    console.log(PI);
    console.log(sqrt(+arg1));
    console.log(square(+arg2));