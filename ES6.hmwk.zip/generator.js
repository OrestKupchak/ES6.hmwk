 const max = process.argv[2];

    const FizzBuzz = function*() {

  let curr = 0
  let val;
      while (curr < max) {
        curr++
        if (curr % 5 == 0 && curr % 3 === 0) {
          val = "FizzBuzz"
        } else if (curr % 3 == 0) {
          val = "Fizz"
        } else if (curr % 5 == 0) {
          val = "Buzz"
        } else {
          val = curr
        }
        yield val
      }
    }()


    for (let n of FizzBuzz) {
      console.log(n);
    }