 let inputs =  process.argv.slice(2);
 let result = inputs.map((elem)=>{return elem.slice(0,1)},[])
                    .reduce((prev, curr)=>{ return prev+curr},'');

    console.log(result);